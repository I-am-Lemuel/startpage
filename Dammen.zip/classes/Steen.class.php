<?php

namespace Dammen;

class Steen
{
    public $kleur;

    public function __construct($kleur)
    {
        $this->kleur = $kleur;
    }
}